#!/usr/bin/env python3
"""
VoiceTrust Demo Script - Integration with SpeechBrain pre-trained models.

Analyze audio files for deepfake detection and trust scoring.
Optimized for Chinese/English voice messages.

Usage:
    # Analyze without speaker verification
    python demo.py --audio sample.wav

    # Enroll a speaker
    python demo.py --audio enrollment.wav --speaker owner --enroll

    # Verify a speaker
    python demo.py --audio message.wav --speaker owner

    # Create test audio
    python demo.py --create-demo test.wav
"""
import argparse
import sys
import os
import json
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

import torch
import numpy as np

try:
    from inference.pipeline import VoiceTrustPipeline, TrustScore
    SPEECHBRAIN_AVAILABLE = True
except ImportError as e:
    print(f"Error importing VoiceTrust: {e}")
    print("\nPlease install dependencies:")
    print("  pip install -r requirements.txt")
    SPEECHBRAIN_AVAILABLE = False


# Default voiceprint storage
VOICEPRINT_DIR = Path(__file__).parent.parent / "data" / "voiceprints"


def print_banner():
    """Print welcome banner."""
    print("=" * 60)
    print("  VoiceTrust for OpenClaw")
    print("  Voice Message Trust Verification System")
    print("  Powered by SpeechBrain Pre-trained Models")
    print("=" * 60)
    print()


def print_result(result: TrustScore):
    """Pretty print analysis result."""
    print("-" * 60)
    print("ANALYSIS RESULTS")
    print("-" * 60)
    print()

    # Component scores
    print("Component Scores (0-100, higher = more trustworthy):")
    print(f"  Deepfake Detection:    {result.deepfake_score:6.2f}")
    if result.speaker_match >= 0:
        print(f"  Speaker Verification:  {result.speaker_match:6.2f}")
    else:
        print(f"  Speaker Verification:  Not checked")
    print(f"  Audio Quality:         {result.audio_quality:6.2f}")
    print(f"  Language Consistency:  {result.language_consistency:6.2f}")
    print()

    # Overall trust
    trust_level = "HIGH" if result.overall_trust >= 70 else \
                  "MEDIUM" if result.overall_trust >= 40 else "LOW"

    print(f"Overall Trust Score: {result.overall_trust:.2f} ({trust_level})")
    print(f"Confidence: {result.confidence:.2f}")
    print()

    # Verdict
    print("-" * 60)
    if result.is_synthetic:
        print("VERDICT: SYNTHETIC SPEECH DETECTED")
        print(f"Spoof Probability: {result.spoof_probability * 100:.2f}%")
    else:
        print("VERDICT: BONAFIDE (Natural Speech)")
        print(f"Synthetic Probability: {result.spoof_probability * 100:.2f}%")

    if result.speaker_id and result.speaker_match >= 0:
        match_status = "MATCH" if result.speaker_match >= 50 else "NO MATCH"
        print(f"Speaker Verification ({result.speaker_id}): {match_status}")
        print(f"  Similarity Score: {result.raw_speaker_score:.3f}")

    print("-" * 60)
    print()


def create_demo_audio(output_path: str, duration: float = 3.0):
    """Create a demo audio file for testing."""
    try:
        import soundfile as sf
        import numpy as np

        sample_rate = 16000
        t = np.linspace(0, duration, int(sample_rate * duration))

        # Generate a simple synthetic voice-like signal
        f0 = 150
        waveform = np.sin(2 * np.pi * f0 * t)
        for i in range(2, 6):
            waveform += 0.3 ** i * np.sin(2 * np.pi * f0 * i * t)
        waveform = waveform / np.abs(waveform).max()

        sf.write(output_path, waveform, sample_rate)
        print(f"Created demo audio: {output_path}")
        return output_path
    except Exception as e:
        print(f"Error creating demo audio: {e}")
        return None


def save_voiceprint(speaker_id: str, embedding: np.ndarray, voiceprint_dir: Path = VOICEPRINT_DIR):
    """Save voiceprint to disk."""
    voiceprint_dir.mkdir(parents=True, exist_ok=True)
    voiceprint_path = voiceprint_dir / f"{speaker_id}.npy"
    np.save(voiceprint_path, embedding)
    print(f"  Saved voiceprint to: {voiceprint_path}")


def load_voiceprint(speaker_id: str, voiceprint_dir: Path = VOICEPRINT_DIR) -> np.ndarray:
    """Load voiceprint from disk."""
    voiceprint_path = voiceprint_dir / f"{speaker_id}.npy"
    if voiceprint_path.exists():
        return np.load(voiceprint_path)
    return None


def list_enrolled_speakers(voiceprint_dir: Path = VOICEPRINT_DIR) -> list:
    """List all enrolled speakers."""
    if not voiceprint_dir.exists():
        return []
    return [f.stem for f in voiceprint_dir.glob("*.npy")]


def main():
    parser = argparse.ArgumentParser(
        description="VoiceTrust Demo - Analyze voice messages for authenticity"
    )
    parser.add_argument(
        "--audio",
        type=str,
        help="Path to audio file to analyze",
    )
    parser.add_argument(
        "--speaker",
        type=str,
        help="Speaker ID for verification",
    )
    parser.add_argument(
        "--enroll",
        action="store_true",
        help="Enroll speaker instead of verifying",
    )
    parser.add_argument(
        "--create-demo",
        type=str,
        metavar="PATH",
        help="Create a demo audio file at the specified path",
    )
    parser.add_argument(
        "--device",
        type=str,
        default="cpu",
        choices=["cpu", "cuda"],
        help="Device to use for inference",
    )
    parser.add_argument(
        "--expected-lang",
        type=str,
        choices=["chinese", "english"],
        help="Expected language in the audio",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output results as JSON",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=0.25,
        help="Speaker verification threshold (default: 0.25)",
    )
    parser.add_argument(
        "--spoof-threshold",
        type=float,
        default=0.5,
        help="Spoof detection threshold (default: 0.5)",
    )
    parser.add_argument(
        "--list-speakers",
        action="store_true",
        help="List enrolled speakers",
    )
    parser.add_argument(
        "--clear-speaker",
        type=str,
        metavar="SPEAKER_ID",
        help="Clear a specific speaker's enrollment",
    )

    args = parser.parse_args()

    # Check SpeechBrain availability
    if not SPEECHBRAIN_AVAILABLE:
        print("Error: SpeechBrain not available. Please install dependencies.")
        sys.exit(1)

    # Handle list speakers
    if args.list_speakers:
        speakers = list_enrolled_speakers()
        if speakers:
            print("Enrolled speakers:")
            for s in speakers:
                print(f"  - {s}")
        else:
            print("No enrolled speakers found.")
        return

    # Handle clear speaker
    if args.clear_speaker:
        voiceprint_path = VOICEPRINT_DIR / f"{args.clear_speaker}.npy"
        if voiceprint_path.exists():
            voiceprint_path.unlink()
            print(f"Cleared enrollment for speaker: {args.clear_speaker}")
        else:
            print(f"Speaker '{args.clear_speaker}' not found.")
        return

    # Create demo audio if requested
    if args.create_demo:
        create_demo_audio(args.create_demo)
        return

    # Check audio file
    if not args.audio:
        print("Error: --audio is required (or use --create-demo)")
        parser.print_help()
        sys.exit(1)

    if not os.path.exists(args.audio):
        print(f"Error: Audio file not found: {args.audio}")
        sys.exit(1)

    # Print banner
    if not args.json:
        print_banner()

    # Set device
    device = args.device
    if device == "cuda" and not torch.cuda.is_available():
        print("CUDA not available, using CPU")
        device = "cpu"

    # Initialize pipeline
    try:
        if not args.json:
            print(f"Initializing pipeline on {device}...")
            print("Note: Models will be downloaded on first run (may take a few minutes)")
            print()

        pipeline = VoiceTrustPipeline(
            device=device,
            verification_threshold=args.threshold,
            spoof_threshold=args.spoof_threshold,
        )
    except Exception as e:
        print(f"Error initializing pipeline: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

    # Enroll speaker if requested
    if args.enroll and args.speaker:
        try:
            if not args.json:
                print(f"Enrolling speaker: {args.speaker}")
                print(f"Audio file: {args.audio}")
                print()

            embedding = pipeline.enroll_speaker(args.speaker, args.audio)

            # Save voiceprint to disk for persistence
            save_voiceprint(args.speaker, embedding)

            if not args.json:
                print(f"Speaker '{args.speaker}' enrolled successfully.")
                print(f"Embedding shape: {embedding.shape}")
            else:
                print(json.dumps({
                    "status": "success",
                    "speaker_id": args.speaker,
                    "embedding_shape": list(embedding.shape),
                }))
        except Exception as e:
            print(f"Enrollment failed: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)
        return

    # Analyze audio
    try:
        # Load existing voiceprints
        if args.speaker:
            voiceprint = load_voiceprint(args.speaker)
            if voiceprint is not None:
                pipeline.load_voiceprint(args.speaker, str(VOICEPRINT_DIR / f"{args.speaker}.npy"))
                if not args.json:
                    print(f"Loaded voiceprint for speaker: {args.speaker}")
            elif not args.json:
                print(f"Warning: Speaker '{args.speaker}' not enrolled. Run with --enroll first.")

        if not args.json:
            print(f"Analyzing: {args.audio}")
            if args.speaker:
                if args.speaker in pipeline.get_enrolled_speakers():
                    print(f"Verifying against speaker: {args.speaker}")
                else:
                    print(f"Warning: Speaker '{args.speaker}' not enrolled!")
            if args.expected_lang:
                print(f"Expected language: {args.expected_lang}")
            print()

        result = pipeline.analyze_audio(
            audio_path=args.audio,
            speaker_id=args.speaker,
            expected_language=args.expected_lang,
        )

        # Output results
        if args.json:
            print(json.dumps(result.to_dict(), indent=2))
        else:
            print_result(result)

            # Recommendations
            print("RECOMMENDATIONS:")
            if result.overall_trust < 40:
                print("  - This message shows signs of manipulation")
                print("  - Recommend additional verification")
                print("  - DO NOT TRUST this message")
            elif result.overall_trust < 70:
                print("  - Some anomalies detected")
                print("  - Review with caution")
                print("  - Consider secondary verification")
            else:
                print("  - No significant issues detected")
                print("  - Message appears authentic")
                print("  - Safe to trust")
            print()

    except Exception as e:
        print(f"Analysis failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
